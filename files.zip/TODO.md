# ShadowChaser — TODO (the single task list)

## What this file is — and how it relates to the handoff
**Two documents, one job each. They must not duplicate.**
- **`HANDOFF.md`** owns *knowledge & current status*: what changed this session, what is
  deployed, how things work now, the hard-won derivations and lessons, what's closed. It is
  the source of truth for whether something is done and for HOW things work.
- **`TODO.md`** (this file) owns *everything still to do*, with its detail inline: open bugs
  and their candidate fixes, UX questions and deliberations, the feature pool, perf/data
  notes, the refactor ledger — ordered by priority. It accretes and is pruned, not rewritten.

**Rules to keep them from drifting:**
1. When an item here is done, **delete it** — HANDOFF records the closure. No "DONE" tombstones.
2. Don't restate narrative status here; keep the task + its detail. HANDOFF holds the story.
3. One coherent change at a time; bump BUILD on every deploy AND every path rebuild.

Last touched: 2026-08-18 — **live cloud "Now" (#F2c) made usable** (HANDOFF §10A). Four days
and ~90 versions; the feature works and is not finished. Fixed this session: the dateline
stripe (a GIBS bbox-edge bug, not our geometry), render 13× faster (`bgAt` was 89% of it),
parallel fetch and a cached frame probe, the globe-vs-Mercator fetch box, storms hollowing
themselves out (a 4-day clear-sky reference, now 10), polar extrapolation, and the ☁-off
bug (which was in `cloud.js`, not `satellite.js`). `test_satellite.js` rewritten — it had
been testing an architecture two rewrites old and its last four sections had never run.
**The four `SESSION-2026-08-*.md` files were folded into HANDOFF §10A and deleted.**

Prior: 2026-08-11 — **cloud-cover overlay (#F2 climatology) SHIPPED** (HANDOFF §10).
ERA5 1991–2020, 0.5°, 8 local-solar-time slices × 12 months, 3.3 MB of WebP; each point
timed to when the eclipse peaks *there* via `findMaximum()`, not to greatest eclipse.
Two canvases (world base + sharp viewport) — read §10.3 before touching the render path,
three plausible alternatives were tried and all lose. Precached since 2026-08-13.
`Cloud.version` must be bumped on every change to that file.

Prior sessions: the narrative for 2026-08-05 → 08-13 lived here with section references into
an older HANDOFF numbering that the 2026-08-12 restructure invalidated — every one of them
pointed at the wrong place. The story belongs in HANDOFF anyway (rule 2 at the top of this
file), so it has been dropped rather than renumbered. **HANDOFF §15 is the change log.**

## PRIORITY ORDER (suggested re-entry)
*(The map is stable and cosmetically finished as of 2026-07-13/14. Offline works. Terrain
shadows are DONE and wired in (HANDOFF §4). Priorities are the USER's to set — this is a
suggestion.)*
1. **#R5 iOS pinch-zoom not blocked** (detail under BUGS). Known cause, known fix —
   `touch-action: pan-y` on the scrollable panels, LEAVING the map container alone. Small and
   contained, but needs a real iPhone to confirm, so it is the user's to verify.
2. **Scan ignores non-location filters** (detail under BUGS). TODO's own note calls this the
   REAL scan win: filter by date/type BEFORE loading chunks instead of walking ~30 of them on
   every first scan. No user-visible change, no data restructuring.
3. **#F1b finish the t-shirt geometry** — 3 failing catalogue assertions in the polar tail.
   Deliberately NOT first: it is the least visible and the most likely to consume a whole
   session. Read HANDOFF §11.4 before starting.
4. **Search temporal tokens** — needs a design decision before any code (low priority; not
   currently bothering the user).
5. Remaining open bugs → UX deliberations → Features.

**Dropped 2026-08-09 — "Overlay sheet pattern".** It was premised on three overlays arriving
at once, each growing its own control cluster. That premise is gone: the shadow scrubber
stays where it is (the user likes it there), shadow-on-globe is shelved, **cloud cover
shipped with a single toggle and no panel at all** (HANDOFF §10 — which rather makes the point),
and the planned desirability heatmap may need no controls at all. Building a
generic control pattern for imagined consumers produces an abstraction that fits none of
them. **`.sheet` already exists, works, and has a real consumer in the poster** — it will
still be there when an overlay actually needs a panel, and by then its contents will be
known. Do not resurrect this as speculative work.

---

## MAP COSMETICS — mostly DONE (2026-07-12/13). What remains:
- **Limb not perfectly round** — the globe silhouette shows slight facets at grazing angle
  (ellipsoid tessellation). Only improvable with finer globe geometry (lower
  `maximumScreenSpaceError`) at a memory cost. Low priority; decide if worth it.
- **Raster sharpness ceiling.** NE2 is now `ne2_mercator.jpg`, 4096x4096 (Web Mercator, not the
  old 4096x2048 equirect — see HANDOFF §7.2), so it's sharper than before but still soft at
  close-in views. 8192x8192 would be a large GPU-texture jump on the platform we fought an OOM
  on, so DO NOT just swap the image. The right answer is a **tile pyramid** (only visible tiles
  resident). Revisit only if the softness actually bothers you in the field.
- **Thunderforest Landscape basemap** — needs an **API key**, which for a static PWA must sit in
  client-side code where anyone can read it. Same for Stadia/Stamen and Mapbox. Decide whether
  that's acceptable. Free/no-key providers already ship in the Settings picker (Esri x5,
  OpenTopoMap, OSM). Menu: https://leaflet-extras.github.io/leaflet-providers/preview/
- **Preload the three About-link eclipses.** Their chunks load on demand, so the 10th-century
  Ouagadougou link makes you wait. Preloading whole centuries is overkill; the right fix is to
  generate three small per-eclipse extract files at build time and special-case their load.
  A build-step change, not a code tweak — do it deliberately.
- **A second "travel this way" arrow?** The sun arrow points at the SUN's azimuth at maximum
  (from the pinned location). A field user might also want the direction to the CENTRELINE —
  i.e. the shortest hop to gain totality. Different quantity, roughly perpendicular; would need
  to be visually distinct so the two are never confused. Deliberate before building.

### Shipped this session (do not re-open)
Sun arrow (red, filled dart, per-frame constant screen size, base locked to the pin) · push-pin
observer marker with contact dot · orange GE diamond with distance scaling · flat city dots (no
outline rings) · dark warm-charcoal borders that fade with zoom-out · 50m borders on BOTH
platforms (Andorra has borders again) · umbra ovals fade instead of blinking · city labels drawn
whole + per-city EllipsoidalOccluder horizon test (no more half-eaten "TY", no hemisphere blink) ·
hamburger Details icon (SVG, gold) · tab order Search/Map/Details/Settings on both layouts ·
settings sub-tab order + scroll-to-top + app-standard text size · online basemap picker (7
providers, live swap) · polar hole filler (sub-tile imagery layer, colour SAMPLED from each
provider's own z=0 tile) · load crawlbar · Details-tab throb on new location · date label to the
corner · About-text deep links (select + recentre) · placename kept beside coords · clear-location
actually clears · landscape space reclaim · mobile install note · banner slimmed.

---

## OPEN — UI / COPY
- **Star on an already-saved eclipse should UPDATE its location, not just unsave.** Today the
  star is a pure toggle: press it on a saved eclipse and the entry is deleted. If a location is
  set and it differs from the saved one, saving over the top should overwrite the location —
  that is what "save it again from here" plainly means. Unsaving then needs its own affordance
  (the bin in the log row already exists, so possibly the star simply never unsaves).
- **Share button output needs work.** The shared text/URL is thin. Decide what a shared eclipse
  should actually carry — date, type, the recipient's local circumstances or the sender's,
  duration, a map image? — before touching the code; this is a content decision, not a
  formatting one.

- **Poster picks: none and all send the same instruction.** `tsOpen` reads an empty pick set as
  "use everything", so the log toolbar's tri-state checkbox has two states that mean the same
  thing to the poster — only the dash (some picked) actually narrows it. Harmless today, but the
  control now *shows* the distinction it does not have. Fix in `tsOpen` if it ever matters, not
  in the toolbar (HANDOFF §11.3).

- **Polar ice caps do not participate in the relief fade.** They are opaque fills drawn ABOVE
  `relief`, so past ±85° the map stays solid ice-white while everything else eases back to the
  flat vector fills at high zoom (HANDOFF §7.2). Defensible — it IS ice — and rarely visited,
  but it is an inconsistency in a deliberate visual rule.

- **Where do map options belong? — MOSTLY DECIDED, shipped 2026-07-29.** On-map controls now
  exist: basemap picker top-right (Street/Topo/Sat), shadow/cloud toggles top-left (HANDOFF
  §13.3). Desktop Map sub-tab still holds only the force-offline toggle — decide if that's worth
  folding into the on-map strip too, or leave it.

- **Should HYBRID eclipses match a search for "total"?** They ARE total along part of their path
  (569 of 11,898). Arguments: a chaser searching "total" near a location would want a hybrid that
  is total *there*; against: it muddies a precise term, and hybrids are already their own type.
  Middle path: include hybrids in "total" results but label them clearly as hybrid, OR make
  totality-at-the-chosen-location the criterion when a location is set. **Needs a decision, not a
  guess — it changes what the app claims.**

- **Search temporal tokens — open-ended *backward* ranges are useless (the "1999-" / "now-"
  problem). NEEDS A DESIGN DECISION — do not code yet. Low priority.** Today a trailing-dash range
  like `1999-` lists ascending from the catalog's START (year ~1 or earlier), so the user drowns
  in ancient eclipses and never reaches 1999. **Constraint from Guy: the list must ALWAYS read the
  same direction — no query-dependent sort flipping.** So the fix is NOT "sort descending for
  backward ranges." Open options to weigh (consult before implementing):
    (a) Auto-scroll/jump the list to the anchor year so the relevant region is on screen, while
        keeping the global ascending order intact.
    (b) Default the open end to a bounded window (e.g. `1999-` = the N years before 1999) instead
        of all-of-history.
    (c) Drop/disallow the bare trailing-dash form and steer users to explicit ranges
        (`1950-1999`).
    (d) Keep ascending but show a result count / "showing first N of M" + a way to page toward
        the anchor.
  Decide the model first, then align the example text. The underlying asymmetry Guy noticed
  (`today+` exists; `now-` semantics are murky) gets resolved by whichever model wins.

---

## VERIFY (logic — handle with care; not pure copy)
- **Offline timezone for odd zones (Gander −3:30, Nepal +5:45).** Timezones resolve offline
  via the **tz-lookup** polygon DB, which DOES return the correct IANA zone (`America/St_Johns`,
  `Asia/Kathmandu`). The open question is whether details.js applies the half/quarter-hour
  offset (and historical/future DST for the eclipse date) correctly. Verify with a Gander and
  a Kathmandu test case across a couple of eras before declaring it handled.

---

---

---

## 🧭 STANDING RULE — USE THE RENDERER'S API BEFORE HAND-ROLLING
*(Active renderer is **MapLibre + deck.gl** (`js/map.js`). The dormant `cesium` branch is
parity-only — see PARITY.md. The canonical, renderer-neutral statement of this rule lives in
HANDOFF §5; this is the task-side reminder + the outstanding tech debt.)*

**Rule: before writing per-frame code or geometry tricks to fake a visual effect, name the
API (MapLibre / deck.gl on the live app; Cesium on that branch) that should do it. If you can't
name one, say so out loud rather than hacking silently.** Most churn in this project came from
treating the renderer as a dumb surface to outsmart rather than an engine with a considered API.

**Corollary — beware "safety rails" (renderer-agnostic).** Constants added as harmless guards
have twice become the DOMINANT term: a 2 km arrow floor (at street zoom the whole view is ~2 km,
so the arrow filled the screen); a 16 px screen floor applied AFTER a 300 km ground cap (at globe
zoom the floor exceeded the cap, so `Math.max` threw the cap away and the arrow spanned Africa).
If two limits can fight, write down which must win — and check the arithmetic at BOTH extremes.

### Hand-rolled tech debt on the **cesium branch** (dormant — does NOT apply to the live MapLibre app)
Recorded so it isn't lost if that branch is ever revived. These name Cesium primitives with no
MapLibre equivalent; do not port them to `map.js`.
- **Border fade with zoom** — pokes `material.uniforms.color.alpha` every frame; Cesium
  primitives support distance-based appearance natively.
- **Arrow geometry rebuild** — surface geometry recomputed per frame via `CallbackProperty`; a
  `Billboard` with `scaleByDistance` would be GPU-side and free, IF the limb/occlusion problem is
  solved by the engine rather than by hand.

*(The live MapLibre renderer has its own equivalents — e.g. globe occlusion via
`map.transform.isLocationOccluded`, see HANDOFF §8.4. The whole globe-occlusion family — #P2
(paths through the planet) and #R1 (city labels) — is now closed.)*

---

## ⛔ DO NOT DO (verified traps — recorded so they aren't re-attempted)
*(Some traps below name **Cesium** primitives — `CLAMP_TO_GROUND`, `depthFailMaterial`,
order-independent translucency. Those apply to the dormant `cesium` branch only; the live
MapLibre+deck.gl app can't hit them; the equivalent occlusion/depth question (#P2) is now fixed.
The data-key and safety-rail traps are renderer-agnostic.)*
- **Do NOT rename the `ep.centreline` DATA KEY → `centerline`.** Internal JSON key emitted by
  the generator and read by `map.js` (plus the layer id) — distinct from the visible label.
  Renaming requires changing generator output, regenerating EVERY path file, and changing the
  reader in lockstep: a breaking refactor for zero user-visible payoff.
- **Do NOT re-add clamp-to-ground on iOS.** `heightReference: CLAMP_TO_GROUND` and
  `clampToGround: true` (the *classification* kind) crash iOS Safari on the offline transition
  (`f.globe` render error) and gap polylines at certain zooms. Confirmed isolated: desktop runs
  the fill primitive fine, so the fill was never the crasher — clamp was. Occlusion/limb
  problems must be solved another way (basemap-as-globe-surface, or depth-tested surface
  geometry). NOTE the distinction: plain height-0 geometry we DO use — `clampToGround: false`
  polylines (arrow, paths) and depth-tested billboards/points (markers, dots) — is fine; only
  the classification clamp is banned.
- **Do NOT lift the eclipse paths off the ground.** They are drawn at EXACTLY height 0. Any lift
  parallaxes them across the surface by `height × tan(view angle)`: a 2.5 km lift (tried) displaces
  the path by **4.3 km** at 60°; even a 50 m lift is 29 m at 30° — meaningless noise on a centreline
  computed to ~15 m. **This corrupts the measurement the app exists to make.** If something occludes
  a path, use `depthFailMaterial` (already in place), which costs zero geometric offset.
- **Do NOT re-add a screen-size FLOOR to the sun arrow.** A `Math.max(L, MIN_PX × mpp)` applied
  after the ground CAP is LARGER than the cap at globe zoom, so it throws the cap away and the
  arrow spans a continent. The CAP must be the last word. (Likewise a 2 km absolute floor became
  the dominant term at street zoom, where the whole view is ~2 km, and the arrow filled the
  screen.) **Beware any constant added as a "safety rail": check the arithmetic at BOTH extremes.**
- **Don't bother disabling order-independent translucency on mobile.** We tried it chasing the
  backgrounding crash; it did NOT help (the framebuffer cuts — skybox/atmosphere/FXAA/MSAA off
  — did). No evidence it broke anything either — it's simply pointless. Left at default.

---

## BUGS — open (detail; status in handoff)
- **Two eclipses with a missing umbral sliver — WON'T FIX for now; documented so it isn't
  rediscovered.** `332-03-13` (cat 5554) and `2485-12-07` (cat 10668), both type `A+`, are the
  only two central eclipses in all 11,898 that produce NO umbral limb at all. Verified against
  Jubier's KMZs: he draws a single tiny annular edge for each — **50.8 km / 14 pts** (332) and
  **117.4 km / 37 pts** (2485), plus one terminus point tacked on either end (164 km and 222 km
  end-to-end). His "Northern Umbra Limit" and "Southern Limit" are the *same curve reversed*,
  point-for-point — consistent with `A+` meaning one edge only. Everything else on both records
  is correct (penumbra, green curve, terminators).
  **Rarity:** these are the two smallest umbral footprints in the catalog. A normal `A+` peer
  traces 100–240 points, and both 332 (γ 1.00358) and 2485 (γ 1.02422) sit inside the peer γ
  range, so it is NOT a marginality cutoff — 332 is a milder non-central than peers at γ 1.02
  that trace fine.
  **If it ever needs fixing:** the one-limit branch in `build_path` samples `tmin..tmax` at
  **1201 fixed steps** and requires `len(_tn) >= 2` before it will walk a limb. On an arc this
  short the annular phase may fall between samples, so the walk never starts. **Untested
  hypothesis — instrument `umbra_pair` over both records' t-ranges to confirm before coding.**
  If confirmed, the fix is a scale-aware resample of that interval, the same principle as the
  existing narrow-band densification (`NARROW_KM`) — not a new mechanism. Do NOT widen the
  1201-step sampling globally; that costs every eclipse to serve two.
  **Regression test if attempted:** the other 33 `A+` records must be byte-identical after.
- **Penumbra threshold offset (low priority — user accepts "close").** Our penumbra limit
  sits ~7–10 km INSIDE Jubier's, asymmetric N/S. NOT a single term (dropping the cone-narrowing
  term fixes north, worsens south) — suggests a direction-dependent (refraction/limb) term. The
  implicit-contour penumbra prototype reaches ~9 km. Pursue only if chasing sub-km everywhere;
  otherwise "naturally fuzzy" is fine. Eventually migrate penumbra onto the implicit engine as
  {max magnitude = 0}.
- **#R5 iOS pinch-zoom not blocked.** `user-scalable=no` is deliberately ignored by iOS Safari.
  Real fix: `touch-action: pan-y` on the scrollable panels (allows scroll, blocks pinch) while
  LEAVING the map container alone (the map needs pinch to zoom). Must test on a real iPhone.
- **Safari geolocation fails; installed PWA works.** Check secure-context / permissions / Brave
  default block vs the code path.
- **Slow first load from local-disk server** — minutes vs seconds. *(Partly explained: every asset
  downloads TWICE on a build change — see PERFORMANCE / DATA. That is pre-existing and mostly
  served from disk cache in production (~11 s load, DOMContentLoaded ~950 ms), so profile the
  LOCAL-server case specifically before assuming it's the same cause.)* Profile the chunk-fetch
  pattern.
- **Scan ignores non-location filters** — always scans all 5 centuries regardless of other
  *(This is the REAL scan win. Measured alternative — splitting partials into separate files —
  saves only ~1% of payload and was rejected. Filtering by date/type BEFORE loading chunks would
  cut far more, cost nothing in user confusion, and needs no data restructuring. First scan after a
  map click walks ~30 chunks; subsequent scans are in-memory and free.)*
  Original note:
  active filters. Pre-existing; harmless offline (SW precaches all besselian centuries) but
  inefficient.

---

---

## FEATURES — EASY
- **Viewing conditions in the details panel.** With a location set, show two indicators:
  **terrain-shadow visibility** (is the sun above the local horizon at max, or behind a
  ridge — the terrain shadow engine already answers this, HANDOFF §4) and **cloud-cover
  likelihood** (`Cloud.sampleAt(lon, lat)` returns the mean cloud fraction at that point,
  timed to the local maximum — see HANDOFF §10). Both are already computed; this is presentation.
  Answers "should I stand here?" without making the user read two overlays and interpolate
  by eye. Notes for whoever builds it:
  - `sampleAt` returns null until the cloud layer has been on once, since it reads the
    slices that render loaded. Either fetch on demand or show the row only when populated —
    do NOT silently render a zero.
  - Mean cloud amount is **not** the probability of seeing totality (50% could be
    half-covered daily or clear on half the days). Whatever wording is used must not
    imply odds. One qualifying line, not a paragraph.
  - 0.5 deg is ~55 km: it cannot see sea breezes, lee clearing or valley fog. The terrain
    indicator is sharp, the cloud one is regional. Do not present them as equally precise.
- Thumbnail path map per list row (small SVG) — MOBILE ONLY (not desktop).
- Century scroller on the mobile right edge.
- KMZ download.

## FEATURES — MEDIUM
- **#F4 "Cache this spot" — offline tiles around the pin.** With a location and an eclipse
  selected, one press downloads basemap and terrain tiles for a small box round the pin, so the
  detail you need on the day survives having no signal. Plan at home, navigate in a field.

  **DESIGN DECISION, already taken — 10 km radius, max zoom 15.** Everything about whether this
  is a button or a project follows from those two numbers, so do not quietly widen them.
  A tile covers `40075·cos(φ) / 2^z` km, and because that shrinks in BOTH axes the count scales
  as **1/cos²φ** — Scotland costs 2.5× Ecuador for the same box. For a 20 km box, one raster
  layer, all zooms up to the cap, at ~40 KB/tile:

  | max z | ground res | equator | lat 45 | lat 57 |
  |---|---|---|---|---|
  | 14 | 2.4 m/px | 161 · 6 MB | 243 · 9 MB | 404 · 16 MB |
  | **15** | **1.2 m/px** | **485 · 19 MB** | **868 · 34 MB** | **1,428 · 56 MB** |
  | 16 | 0.6 m/px | 1,641 · 64 MB | 3,172 · 124 MB | 5,272 · 206 MB |
  | 17 | 0.3 m/px | 6,130 · 239 MB | 12,008 · 469 MB | 20,156 · 787 MB |

  z15 shows the field you will park in. z16 quadruples the cost for detail nobody uses at 4 a.m.
  **Terrain is nearly free on top** — Terrarium tops out ~z15 and shadows do not need better
  than z13, so ~115 tiles / 4 MB.

  **The one real blocker is `sw.js:117`:**
  ```js
  if (url.origin !== self.location.origin) return;   // online Esri tiles etc. → untouched
  ```
  Every basemap is Esri or OSM and terrain is `s3.amazonaws.com/elevation-tiles-prod/terrarium/`
  — all cross-origin, all currently passed straight through, so nothing cached would ever be
  served back. That line is also the current guarantee that the SW never interferes with live
  tiles, so the branch that replaces it wants care and its own test.

  **The rest, in order:** bbox → tile list (~15 lines of arithmetic); fetch with concurrency into
  a named cache — **reuse `precache()` in sw.js, do not write a second one**; cancellable
  progress UI, because a minute of downloading must be stoppable; and per-area "cached · 34 MB ·
  delete". At tens of MB per spot that is enough — a storage MANAGER would be over-building, but
  shipping with no way to see or delete what was stored turns a good feature into a phone that
  quietly fills up.

- **Compass built into the sky tracker.** Guy has ideas for how it should function and look —
  discuss the design before coding.
- Server-side share page (`followtheshadow.com/share?e=XXXXX`) — static HTML reading the
  existing JSON, rendering a formatted summary + map image. The only way past the plain-text
  ceiling of `navigator.share`/`mailto`. Also the home for "prettier share" visual polish.
- Splash / title page for installed-PWA mode; app icon; app logo / eclipse symbol.
- Night-sky-during-totality view — planets/comets/bright stars near the Sun at totality,
  positioned for the selected eclipse.

## FEATURES — HARD
- **Greatest duration for ALL eclipses (not just the 94).** ⇒ **Handoff exists:
  `docs/GREATEST-DURATION.md` — read it first, don't re-derive any of this.**
  Greatest eclipse ≠ greatest duration: GE is where the axis passes closest to the Earth's
  *centre*; longest totality is elsewhere. Espenak's `duration_secs` is the duration at GE,
  not the maximum. Measured on 25 modern eclipses: median +0.07 s (negligible) but max
  +49.8 s and up to 10,686 km away (2002-06: GE 22.8 s → 72.6 s). So "where and when is this
  eclipse at its longest" is a real, unanswered question, and not one click away on Jubier.
  DONE already: the 94 eclipses with *no central line* (`tools/noncentral_durations.py`,
  surfaced by `details.js:maxDurationRows()`). This item is the general case.
  The hard part is NOT the astronomy — `totality_seconds()` already gives duration at a
  point, validated to 40 ms against Espenak on observed-ΔT eclipses. The hard part is a
  trustworthy *global search*: the duration surface is a long curved ridge along the central
  line, and the hill climb used for the 94 can stall on it or wander. Handoff §5 proposes
  parametrising by time along the central line (1-D scan) instead of searching lat/lon (2-D).
  Also decide storage: 3 fields × 11,900 records ≈ 400 KB on an index.json that already
  loads at startup — may belong in the Besselian chunks instead. Budget hours, make it
  resumable, and spot-check 2017-08-21 / 2024-04-08 against published values first.
- **Path unification — all curves on one implicit-field engine (architectural vision).** Every
  path = the zero level set of a scalar field evaluated at each ground point's own moment of
  greatest eclipse, traced by one shared predictor–corrector:
    green     = {sun altitude at max = 0}        (DONE — sub-km)
    umbra     = {ever-total depth = 0}           (current: perpendicular_limits + analytic dispatch)
    penumbra  = {max magnitude = 0}              (prototype ~9 km)
    mag isolines = {max magnitude = c}           (enables Jubier's 0.2/0.4/0.6/0.8 curves free)
    centreline = ridge of the depth field        (max-finder, not a zero — mild extra work)
    terminator/sunrise-set = intersection of two conditions
  One engine parameterized by field + level (+ intersection mode) replaces the current
  hodgepodge. PHASED: migrate one curve at a time, validate, swap in only when it beats the
  incumbent everywhere. Suggested two-branch discipline: freeze the shipped generator
  (bugfix-only) as stable truth; develop the unified engine as experimental successor.
  ~4–6 phased sessions. Next phase: penumbra onto the engine.
- **#F2c Live cloud — FINISH IT.** Working and shipped-ish; HANDOFF §10A has the whole model,
  every trap, and the harness. Remaining, in the order they matter:
  1. **Polar orbiters above ~65°N.** Geostationary sees *nothing* there — measured weights on
     the 2026-08-12 track are 0.000 at 72–80°N, so **the Greenland leg of the track this app
     exists for is blank**. This is a correctness gap, not polish. `VIIRS_*_Brightness_Temp_BandI5_*`
     and `MODIS_*_Brightness_Temp_Band31_*` give 100% coverage there. Two catches: GIBS serves
     them at `P1D`, not `PT10M`, and they are colour-palette rendered — each needs its own
     decoded map, do NOT inherit GOES's (§10A.8). Same temperature model, weighted by recency
     instead of viewing angle, blended rather than switched at the boundary.
  2. **The visible band by day, to ADD low cloud.** Infrared cannot see marine stratus, which is
     exactly the cloud that ruins an eclipse. A total eclipse is always in daylight along the
     track and `hasNight()` already knows the terminator. Must add, never gate — gating on the
     coarse mask was tried and produced tile edges (§10A.8).
  3. **Speckle at high zoom** — the clear-sky grid is 39 km under 4 km imagery. Raising `BG_W`
     to 2048 is the low-risk half (0.18°, ~46 MB across five satellites; 4096 is 185 MB and not
     viable on a phone). Making the grid follow zoom is the thorough fix and is the riskiest
     change left — §10A.4 records that a non-world grid is what produced the "Minecraft blocks",
     and the cache would have to key on the box.
  4. **Cache-friendly URLs.** Every pan is a fresh bbox, so nothing is ever reused from the
     browser cache. Snapping the fetch box to a grid fixes it but moves the geometry `compose`
     and `place` receive — verify through the harness (§10A.10) before shipping.
  5. **A fresher GOES than GIBS.** ~20–40 min is GIBS's floor. CIRA RAMMB SLIDER (~5 min) and
     NOAA's AWS ABI buckets are the candidates; neither is tested, and the assistant needs
     `rammb-slider.cira.colostate.edu` in its egress allowlist to measure it (§10A.7).
- **#F2b Cloud-cover — the FORECAST half. STARTS FROM SCRATCH.** `js/forecast.js` and
  `tools/checks/test_forecast.js` were written 2026-08-15, never wired into `index.html`, never
  committed, and are **lost** — confirmed against git 2026-08-18. `test_forecast` has been
  removed from `run.js`. What was learned before they vanished, and is worth not re-deriving:
  Open-Meteo's own `calculateQueryWeight()` charges **at least one call per location, and
  locations sum** — batching 400 points into one request is 400 calls, not one. 600/min,
  5,000/hr, 10,000/day, per-user-IP because the calls run in the browser. Consequence: a
  forecast field is **zoomed-in by construction** — 0.5° over a 120°×40° path is 19,200 points,
  two days of quota for one render.
  The original framing, still correct: **Inside about a week of an eclipse, switch to live
  forecast data if a freely available source exists** — no key, no quota, cacheable for
  offline. That week is when a chaser commits to travel, and climatology is worthless at
  that range: a 40%-cloudy-in-August average tells you nothing about next Tuesday. The
  handover should be driven by days-to-eclipse. Rendering is solved twice over — `js/cloud.js`
  owns a canvas layer, a palette and a point sampler, `js/satellite.js` owns a live overlay
  and the `Average | Now` strip is a third cell away from carrying a forecast (§10A.1).
  **The open question is entirely the data source**, and it is harder than the climatology one was: forecasts are current-state
  services with quotas, where ERA5 was a one-time static download. Do not start by writing
  code. Note the timing subtlety already solved for climatology (HANDOFF §10.2) applies here too —
  a forecast must be sampled at each point's own local maximum, not at greatest eclipse.
- **#F3 Animated shadow on globe with time slider** — scrub the umbra/penumbra across the map in
  real time. Most on-brand feature. Distinct from the terrain-shadow scrubber that shipped:
  that scrubs *terrain* shadows at one place; #F3 animates the *umbra/penumbra footprint*
  sweeping the Earth. The terrain-shadow scrubber (`shadow-ui.js` `setShadowTime` owner) is a
  clean precedent for the time-plumbing.
- **#F1b T-shirt poster — finish the geometry.** SHIPPED and usable (HANDOFF §11.4), but
  `tools/checks/test_tshirt.js` **fails 3 catalogue-wide assertions**: one band over 8% of the
  map, some bands drawn past their own limbs, some centrelines drawn where the band doesn't
  reach. All in the polar tail, all from the same root: near a pole the corridor's
  cross-section degenerates (for 2015-03-20 the last pair is 164° apart in longitude but 3.7°
  apart on the globe).
  **Before touching it, read HANDOFF §11.4 — two obvious-looking approaches were tried and produce
  visibly worse output.** And rasterise the SVG and LOOK; measuring polygon area cost days.
- **Splash images.** 28 PNGs, sizes in `icons/splash/README.md`, then add the `<link>` tags.
  One design exported at many sizes — or hand a master image over and have it generated.
  Cosmetic: without it iOS opens on the manifest background colour, which matches the app.

---

## PERFORMANCE / DATA
- **Splitting partial eclipses into separate on-request files: MEASURED, NOT WORTH IT.**
  Partials are 4,200 of 11,898 (35.3%) — but only ~3.5 MB of the 10.1 MB besselian cache, and they
  have NO central path, so they add ~nothing to the 274 MB of path data that dominates storage.
  Net saving ≈ 1% of total payload, in exchange for a new loading mode, a UI affordance, and
  "why can't I find my eclipse?" confusion (partials are exactly what a birthday/location search
  expects to return). The real scan win is the item below — filter BEFORE loading chunks.
- **Every asset downloads TWICE on a build change (real, measured, PRE-EXISTING).** The page
  requests `js/map.js?v=BUILD`; `sw.js`'s precache lists say `js/map.js`. Different URLs → two
  network fetches, for scripts, basemap layers, and every besselian/path chunk. Confirmed in the
  network panel (~317 requests, 22 MB). It has ALWAYS been there — it was present throughout the
  successful offline milestone — so it is wasteful, not breaking.
  **Two failed attempts (do not repeat):** (a) deferring the DATA precache to a post-load "warm"
  pass — fixed nothing for the shell/scripts; (b) a single-flight `fetchOnce()` in the SW keyed on
  the tag-free URL — CANNOT work, because on a build change the page is controlled by the OLD
  service worker while the NEW one installs and precaches in a separate scope: the two never share
  an in-flight map.
  **The actual fix (for a dedicated session):** stop precaching anything the PAGE fetches for
  itself. The fetch handler already caches on demand, so the shell scripts/CSS don't need to be in
  the install list at all; precache only what the page never requests (the MapLibre CSP **worker**
  + vendor assets, out-of-range besselian/paths). Then measure the network panel again. Do this
  calmly, on a
  branch, with an offline test after — `sw.js` is the most fragile file in the project.
- **Path JSON size — curve thinning (RDP).** Full-loop traces + pole tips added points. Reduce
  size WITHOUT losing accuracy via Douglas–Peucker decimation per curve at ~200–500 m (far
  below visible-at-max-zoom). Apply to centreline + umbra limits; penumbra + terminators are
  candidates. Expected 30–60% smaller, zero visible change. Verify post-thin curves stay within
  tolerance (re-check tip cusps). Secondary: delta-encode coords before gzip.
- Path thumbnails for list rows — feasibility/size for 5 centuries of tiny scaled flat-map
  paths.
- Drop or make-optional pre-1000 CE eclipses — cost/benefit on load/data shed.
- **Trim unused Cormorant Garamond weights** — re-check against the current (first-person)
  About text before trimming.

---

## INFRA (durable; keystones of the offline goal)
- **The test suites cannot run as checked out.** `tools/*.js` compute `ROOT` as
  `__dirname/../..`, which assumes they live in `tools/checks/`; in the current tree they sit in
  `tools/`, so `ROOT` lands one level above the repo and every suite dies on ENOENT. Every run
  on 2026-08-09 was from a throwaway `tools/checks/` copy. Move the files or change the constant
  — but do it once and deliberately, because `run.js` and all five suites share the assumption.
- **Cache skew is a solved problem now, but only if the tool is used.** `node tools/set_build.js`
  rewrites `var BUILD` and all 20 `?v=` stamps together. Bumping BUILD by hand renames the SW
  cache while leaving every asset URL on the old string, and `sw.js` matches with
  `ignoreSearch: true`, so the old files keep being served. This cost a full session (HANDOFF
  HANDOFF §4). `test_hygiene` fails on drift.
- **Git-LFS vs GitHub-release bundle** for the large path-chunk files — decide before
  open-sourcing.
- **Open-source prep** — licensing/attribution for the **live stack**: MapLibre GL JS (BSD-3),
  deck.gl (MIT), Natural Earth (public domain), NASA Blue Marble, eclipse data (Espenak/Meeus),
  Terrarium DEM tiles (the shadow engine's source). (The dormant `cesium` branch additionally
  carries Cesium, Apache-2.0 — only relevant if that branch is ever shipped.)
- **Production bundling** (single JS/CSS) — optimization, not a blocker (SW precaches
  individual files fine).
- **"Download everything for the field" toggle** — a Settings option (while online) to precache
  the *full* paths set (~274 MB) so any eclipse, any era draws offline. Today the SW caches the
  1900–2100 range + all besselian; out-of-range eclipses draw offline only if viewed online
  first. Needs progress UI, quota handling, partial-failure recovery, clear-cache control.
  Build only if a real user asks.

---

## REFACTOR LEDGER
- **Pass A** ✓ — split inline script into `js/` modules.
- **Pass B** ✓ — event-driven AppState.
- **Always-selected eclipse** ✓ — removed deselect UI and most null branches.
- **map.js platform consolidation** ✓ (2026-07-11) — scattered `isWide()` branches collapsed
  into one declarative `PROFILE` (render + data settings, decided once). Two layout-only
  media queries left live intentionally.
- **Pass C** — deferred. Tackle when a feature/bug motivates it:
  - Init-time preconditions patchy: three "init-time only" early-returns exist because events
    fire before `selectNextEclipse` completes. Fix: wire selection before subscribers, or
    buffer events until init completes.
  - Search input still DOM-driven (not on AppState).
  - `map.js` still large/single-file (split deferred until a bug motivates it). Still carries
    dead `corridorToPolygonData` (harmless; remove only as part of a real verified refactor).
    Also `sunArrowImage()` is now unused (billboard arrow replaced by surface geometry) —
    remove in the next map.js cleanup pass.
  - `AppState.on()` — **now has real subscribers** (`js/map.js` redraws, `js/cloud.js`).
    No longer speculative; leave it.
  - **Connectivity state** — now a real subsystem (post 2026-07-29 rewrite): active probe (3 s
    timeout, cache-busted, 15 s poll + event-driven, 3 s reprobe on failure), two-strike debounce,
    `_forceOffline`, and `applyOnlineState()` driving imagery, vectors and the pole filler. Still
    lives in `js/map.js`, not yet promoted to its own module. The stated trigger was a
    *second* connectivity-dependent feature. **Cloud climatology did NOT become one** — it is
    static files, precacheable, no connectivity logic at all. **#F2b (forecast) will be the
    real trigger**, since it genuinely needs online/offline handover. Do not promote before
    then; the module would have one consumer and imagined requirements.
  - **Comment cleanup pass on map.js** — several build-to-build war-story comments could be
    condensed now that the approach is settled.

---

## LEGACY GENERATOR NOTES — "ROAD TO PURITY" (SUPERSEDED; reference only)
> **⚠ Describes the older *cone-limit-splitter* approach (generator ~2026-06-21c).** The
> shipped generator now produces umbral limits via `perpendicular_limits` (with `dep_local`) +
> analytic `umbra_pts` dispatch + exact green-line termini (`_terminate_on_green`); the dead
> `cone_limit_split` was removed. The pole-kernel / sliver / threshold concerns below MAY be
> obsolete — **reconcile against current code before acting.** Preserved so the reasoning isn't
> lost.

1. **Pole kernel — 1522-class.** The (old) cone trace SPURS BACK near ±86°, so the limb folds
   at the pole. Fix idea: dense near-pole resampling / pole-aware corrector.
2. **Sub-resolution slivers — the 8** (|γ|≈1, lat 61–75°). Cone returned None on contours
   smaller than the 25 km step. Fix idea: scale-aware step + closure + min-length.
3. **Retire the envelope + guard + suppress-fold** — only after 1 & 2, with a full-catalog
   no-regression pass.
4. **Derive/remove threshold gates** — 50 km median, 30° fold, 20° accept, 150 km tip-trim,
   0.3° closure tol. Derive from geometry where possible.
5. **Optional perf — bound the runaway trace.** Low value now that imap_unordered stops the
   straggler stall.
