#!/usr/bin/env node
/* Run every check. From the repo root:  node tools/checks/run.js
   Needs jsdom:  npm i jsdom   (dev-only; the app itself has no build step). */
const { execFileSync } = require('child_process');
const path = require('path');

/* test_forecast was listed here and its file was never committed, so the runner
   reported a failing suite that did not exist — noise that made "N suites
   failing" mean nothing. js/forecast.js went the same way: written 2026-08-15,
   never wired into index.html, never committed, now lost. #F2b starts from
   scratch. Put both back on this list when it is rewritten. */
const SUITES = ['test_hygiene', 'test_details', 'test_userlog', 'test_picker', 'test_tshirt', 'test_satellite'];
let failed = 0;

for (const s of SUITES) {
  process.stdout.write(s.padEnd(16));
  try {
    execFileSync(process.execPath, [path.join(__dirname, s + '.js')], { stdio: 'pipe' });
    console.log('PASS');
  } catch (e) {
    failed++;
    console.log('FAIL');
    process.stdout.write(e.stdout ? e.stdout.toString() : '');
  }
}
console.log(failed ? `\n${failed} suite(s) failing` : '\nAll suites pass');
process.exit(failed ? 1 : 0);
